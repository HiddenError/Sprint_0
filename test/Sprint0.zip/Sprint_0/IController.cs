﻿
namespace Sprint_0
{
    public interface IController
    {
        void Update();
    }
}